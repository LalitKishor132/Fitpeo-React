import React, { useEffect, useState } from "react";
// import Side from '../Side/Side'
import "./Dashboard.css";
import Dollor from "../Asset/dollar.webp";
import Ordes from "../Asset/orders.jpg";
import Wallet from "../Asset/wallet.jpeg";
import Sales from "../Asset/kdkls.jpg";
import Graph from "../Asset/cus.png";
import Profile from "../Asset/sha.jpeg";
import UnderSea from "../Asset/Abstract.jpeg";
import Universe from "../Asset/Universe.jpeg";
import Bulb from "../Asset/Bulb.jpeg";

function Dashboard() {
  const [Dash, setDash] = useState();
  useEffect(() => {
    setInterval(() => {
      setDash(
        <div >
          <div className="MainComponent">
            <div class="SidePanel">
              <span class="title">Dashboard</span>
              <div class="sideName">
                <span class="side_nameFont">
                  <p>Dashboard</p>
                  <p class="Magic">
                    <i class="fa fa-angle-right"></i>
                  </p>
                </span>
                <span class="side_nameFont">
                  <p>Product</p>
                  <p>
                    <i class="fa fa-angle-right"></i>
                  </p>
                </span>
                <span class="side_nameFont">
                  <p>Customers</p>
                  <p>
                    <i class="fa fa-angle-right"></i>
                  </p>
                </span>
                <span class="side_nameFont">
                  <p>Income</p>
                  <p>
                    <i class="fa fa-angle-right"></i>
                  </p>
                </span>
                <span class="side_nameFont">
                  <p>
                    <i class="bi bi-question-square"></i>Promote
                  </p>
                  <p>
                    <i class="fa fa-angle-right"></i>
                  </p>
                </span>

                <span class="side_nameFont">
                  <p class="Help">
                    <span class="material-symbols-outlined">live_help</span>
                    <span>Help</span>
                  </p>
                  <p>
                    <i class="fa fa-angle-right"></i>
                  </p>
                </span>
              </div>
              <div class="Profile">
                <div class="Image_profile">
                  <img src={Profile} alt="Profile" height="40px" width="40px" />
                </div>
                <div class="Position">
                  <p class="Name">Shahrukh Khan</p>
                  <p className="Name1">Actor</p>
                </div>
                <div class="Arrow">
                  <i class="fa fa-angle-down"></i>
                </div>
              </div>
            </div>

            <div class="leftSide">
              <div class="leftSide1">
                <div class="NameComponent">
                  Hello Shahrukh<span>&#128075;</span>,
                </div>
                <div class="form">
                  <i class="fa fa-search"></i>
                  <input
                    type="text"
                    class="form-control form-input"
                    placeholder="Search"
                  />
                </div>
              </div>

              <div className="Cardsv col-md bg-dark">
                <div className="Cards_coin">
                  <div>
                    <img src={Dollor} alt="ern" height="100px" width="100px" />
                  </div>
                  <div style={{ marginTop: "20px", textAlign: "left" }}>
                    <span style={{ opacity: "0.7", fontSize: "18px" }}>
                      Earning
                    </span>
                    <br />
                    <span style={{ fontWeight: "700", fontSize: "20px" }}>
                      $198k
                    </span>
                    <br />
                    <span
                      style={{
                        color: "#00ff7f",
                        fontWeight: "900",
                        fontSize: "16px",
                      }}
                    >
                      37%
                    </span>
                    <span style={{ fontSize: "17px" }}> this month</span>
                  </div>
                </div>
                
                <div class="Cards_coin" style={{ display: "flex" }}>
                  <div>
                    <img src={Ordes} alt="ern" height="100px" width="100px" />
                  </div>
                  <div
                    style={{
                      marginTop: "20px",
                      textAlign: "left",
                      paddingLeft: "10px",
                    }}
                  >
                    <span style={{ opacity: "0.7", fontSize: "18px" }}>
                      Orders
                    </span>
                    <br />
                    <span style={{ fontWeight: "700", fontSize: "20px" }}>
                      $2.4k
                    </span>
                    <br />
                    <span
                      style={{
                        color: "red",
                        fontWeight: "900",
                        fontSize: "16px",
                      }}
                    >
                      2%
                    </span>
                    <span style={{ fontSize: "17px" }}> this month</span>
                  </div>
                </div>

                <div class="Cards_coin" style={{ display: "flex" }}>
                  <div>
                    <img src={Wallet} alt="ern" height="100px" width="100px" />
                  </div>
                  <div
                    style={{
                      marginTop: "20px",
                      textAlign: "left",
                      paddingLeft: "10px",
                    }}
                  >
                    <span style={{ opacity: "0.7", fontSize: "18px" }}>
                      Balance
                    </span>
                    <br />
                    <span style={{ fontWeight: "700", fontSize: "20px" }}>
                      $2.4k
                    </span>
                    <br />
                    <span
                      style={{
                        color: "red",
                        fontWeight: "900",
                        fontSize: "16px",
                      }}
                    >
                      2%
                    </span>
                    <span style={{ fontSize: "17px" }}> this month</span>
                  </div>
                </div>

                <div class="Cards_coin" style={{ display: "flex" }}>
                  <div>
                    <img src={Sales} alt="ern" height="100px" width="100px" />
                  </div>
                  <div
                    style={{
                      marginTop: "20px",
                      textAlign: "left",
                      paddingLeft: "5px",
                    }}
                  >
                    <span style={{ opacity: "0.7", fontSize: "18px" }}>
                      Total Sales
                    </span>
                    <br />
                    <span style={{ fontWeight: "700", fontSize: "20px" }}>
                      $89k
                    </span>
                    <br />
                    <span
                      style={{
                        color: "Green",
                        fontWeight: "900",
                        fontSize: "16px",
                      }}
                    >
                      11%
                    </span>
                    <span style={{ fontSize: "17px" }}> this month</span>
                  </div>
                </div>
              </div>

              <div class="overviewPanel">
                <div class="OverviewLeft">
                  <div>
                    <span className="Quaterly">
                      <span style={{ fontSize: "25px", fontWeight: "700" }}>
                        Overview
                        <br />
                        <span className="Monthly">Monthly Earning</span>
                      </span>
                      <span>
                        Quaterly <i class="fa fa-angle-down"></i>
                      </span>
                    </span>
                  </div>
                  <br />
                  <div class="Graph">
                    <div class="net1"></div>
                    <div class="net2"></div>
                    <div class="net3"></div>
                    <div class="net4"></div>
                    <div class="net5"></div>
                    <div class="net6"></div>
                    <div class="net7"></div>
                    <div class="net8"></div>
                    <div class="net9"></div>
                    <div class="net10"></div>
                    <div class="net11"></div>
                    <div class="net12"></div>
                  </div>
                  <div class="YearsName">
                    <div>Jan</div>
                    <div>Feb</div>
                    <div>Mar</div>
                    <div>Apr</div>
                    <div>May</div>
                    <div>June</div>
                    <div>July</div>
                    <div>Aug</div>
                    <div>Sep</div>
                    <div>Oct</div>
                    <div>Nov</div>
                    <div>Dec</div>
                  </div>
                </div>
                <div class="Overviewright">
                  <div style={{ textAlign: "left", padding: "20px" }}>
                    <p class="title_Overview">Customers</p>
                    <p style={{ opacity: "0.5", fontSize: "15px" }}>
                      Customers that buy products
                    </p>
                  </div>
                  <div style={{ textAlign: "center" }}>
                    <img src={Graph} alt="error" height="80%" width="80%" />
                  </div>
                </div>
              </div>

              <div className="tableback">
                <table className="table table-hover col-12">
                  <thead className="table-dark">
                    <tr>
                      <th>Product Sell</th>

                      <th>
                        <div class="form">
                          <i class="fa fa-search"></i>
                          <input
                            type="text"
                            class="form-control form-input"
                            placeholder="Search"
                          />
                        </div>
                      </th>
                      <th>
                        <div class="dropdown">
                          <button
                            class="btn btn-light dropdown-toggle"
                            type="button"
                            data-toggle="dropdown"
                          >
                            Last 30 Days
                            <span class="caret"></span>
                          </button>
                          <ul class="dropdown-menu">
                            <li>HTML</li>
                            <li>CSS</li>
                            <li>JavaScript</li>
                          </ul>
                        </div>
                      </th>
                    </tr>
                    <tr style={{ opacity: "0.5" }}>
                      <th style={{ fontWeight: "500" }}>Product Name</th>
                      <th style={{ paddingLeft: "68px", fontWeight: "500" }}>
                        Stock
                      </th>
                      <th style={{ paddingLeft: "50px", fontWeight: "500" }}>
                        Price
                      </th>
                      <th style={{ paddingLeft: "25px", fontWeight: "500" }}>
                        Total Sales
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td className="Image_Undersea_Justify">
                        <div>
                          <img
                            src={UnderSea}
                            className="image_Undersea"
                            alt="Undersea"
                          />
                        </div>
                        <div>
                          <span style={{ fontWeight: "650", fontSize: "20px" }}>
                            Abstract 3D
                          </span>
                          <br />
                          <span style={{ fontSize: "18px", opacity: "0.6" }}>
                            Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit.
                          </span>
                        </div>
                      </td>
                      <td>
                        <p className="p">32 in stock</p>
                      </td>
                      <td>
                        <p className="p">$45.99</p>
                      </td>
                      <td>
                        <p className="p">20</p>
                      </td>
                    </tr>
                    <tr>
                      <td className="Image_Undersea_Justify">
                        <div>
                          <img
                            src={Universe}
                            className="image_Universe"
                            alt="Universe"
                          ></img>
                        </div>
                        <div>
                          <span style={{ fontWeight: "650", fontSize: "20px" }}>
                            Sarphens Ilustrator
                          </span>
                          <br />
                          <span style={{ fontSize: "18px", opacity: "0.6" }}>
                            Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit.
                          </span>
                        </div>
                      </td>

                      <td>
                        <p className="p">32 in stock</p>
                      </td>
                      <td>
                        <p className="p">$45.99</p>
                      </td>
                      <td>
                        <p className="p">20</p>
                      </td>
                    </tr>
                    <tr>
                      <td className="Image_Undersea_Justify">
                        <div>
                          <img
                            src={Bulb}
                            className="image_Bulb"
                            alt="Bulb"
                          ></img>
                        </div>
                        <div>
                          <span style={{ fontWeight: "650", fontSize: "20px" }}>
                            Bulb
                          </span>
                          <br />
                          <span style={{ fontSize: "18px", opacity: "0.6" }}>
                            Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit.
                          </span>
                        </div>
                      </td>
                      <td>
                        <p className="p">32 in stock</p>
                      </td>
                      <td>
                        <p className="p">$45.99</p>
                      </td>
                      <td>
                        <p className="p">20</p>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      );
    });
  });
  return <div>{Dash}</div>;
}

export default Dashboard;
